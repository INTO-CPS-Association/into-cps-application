This directory contains all FMUs avaliable in the project
